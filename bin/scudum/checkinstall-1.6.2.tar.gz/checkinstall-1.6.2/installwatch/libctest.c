/* Dummy program to check your libc version */

int main(void) {
	return 0;
}

